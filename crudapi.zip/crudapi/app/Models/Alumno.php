<?php   
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Alumno extends Model{
    protected $table = "alumnos";

    // protected $fillable = [];

    // public $timestamps = false;
}