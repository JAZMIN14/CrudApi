<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Alumno;

class AlumnoController extends Controller{

    public function index(){
    
        $datosAlumno= Alumno::all();

        return response()->json($datosAlumno);
    }

public function guardar(Request $request){


       $datosAlumno= new Alumno;

       $datosAlumno->nombre=$request->nombre;
       $datosAlumno->control=$request->control;
       $datosAlumno->semestre=$request->semestre;

$datosAlumno->save();

    return response()->json($request);
}

public function ver($id){

    $datosAlumno= new Alumno;
    $datosEncontrados=$datosAlumno->find($id);

    return response()->json($datosEncontrados);

}

public function eliminar($id){

    $datosAlumno= Alumno::find($id);
    if($datosAlumno){
     $rutaArchivo=base_path('public').$datosAlumno->control;

     if(file_exists($rutaArchivo)){
         unlink($rutaArchivo);
     }

       $datosAlumno->delete();
    }
      
    return response()->json("Registro Borrado");

}


public function actualizar(Request $request,$id){

    $datosAlumno= Alumno::find($id);

    if($request->input('nombre')){
        
        $datosAlumno->nombre=$request->input('nombre');
    }

        if($request->input('control')){
        
        $datosAlumno->control=$request->input('control');
    }

        if($request->input('semestre')){
        
        $datosAlumno->semestre=$request->input('semestre');
    }

$datosAlumno->save();

return response()->json("Datos Actualizados");

}

}